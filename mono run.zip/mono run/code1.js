gdjs.GameCode = {};
gdjs.GameCode.stopDoWhile5 = false;

gdjs.GameCode.GDPlatformObjects1= [];
gdjs.GameCode.GDPlatformObjects2= [];
gdjs.GameCode.GDPlatformObjects3= [];
gdjs.GameCode.GDPlatformObjects4= [];
gdjs.GameCode.GDPlatformObjects5= [];
gdjs.GameCode.GDPlatformObjects6= [];
gdjs.GameCode.GDBackgroundObjects1= [];
gdjs.GameCode.GDBackgroundObjects2= [];
gdjs.GameCode.GDBackgroundObjects3= [];
gdjs.GameCode.GDBackgroundObjects4= [];
gdjs.GameCode.GDBackgroundObjects5= [];
gdjs.GameCode.GDBackgroundObjects6= [];
gdjs.GameCode.GDCactusObstacleObjects1= [];
gdjs.GameCode.GDCactusObstacleObjects2= [];
gdjs.GameCode.GDCactusObstacleObjects3= [];
gdjs.GameCode.GDCactusObstacleObjects4= [];
gdjs.GameCode.GDCactusObstacleObjects5= [];
gdjs.GameCode.GDCactusObstacleObjects6= [];
gdjs.GameCode.GDScoreTextObjects1= [];
gdjs.GameCode.GDScoreTextObjects2= [];
gdjs.GameCode.GDScoreTextObjects3= [];
gdjs.GameCode.GDScoreTextObjects4= [];
gdjs.GameCode.GDScoreTextObjects5= [];
gdjs.GameCode.GDScoreTextObjects6= [];
gdjs.GameCode.GDTutorialJuegoObjects1= [];
gdjs.GameCode.GDTutorialJuegoObjects2= [];
gdjs.GameCode.GDTutorialJuegoObjects3= [];
gdjs.GameCode.GDTutorialJuegoObjects4= [];
gdjs.GameCode.GDTutorialJuegoObjects5= [];
gdjs.GameCode.GDTutorialJuegoObjects6= [];
gdjs.GameCode.GDBananaObjects1= [];
gdjs.GameCode.GDBananaObjects2= [];
gdjs.GameCode.GDBananaObjects3= [];
gdjs.GameCode.GDBananaObjects4= [];
gdjs.GameCode.GDBananaObjects5= [];
gdjs.GameCode.GDBananaObjects6= [];
gdjs.GameCode.GDBonusParticleObjects1= [];
gdjs.GameCode.GDBonusParticleObjects2= [];
gdjs.GameCode.GDBonusParticleObjects3= [];
gdjs.GameCode.GDBonusParticleObjects4= [];
gdjs.GameCode.GDBonusParticleObjects5= [];
gdjs.GameCode.GDBonusParticleObjects6= [];
gdjs.GameCode.GDJumpButtonObjects1= [];
gdjs.GameCode.GDJumpButtonObjects2= [];
gdjs.GameCode.GDJumpButtonObjects3= [];
gdjs.GameCode.GDJumpButtonObjects4= [];
gdjs.GameCode.GDJumpButtonObjects5= [];
gdjs.GameCode.GDJumpButtonObjects6= [];
gdjs.GameCode.GDDuckButtonObjects1= [];
gdjs.GameCode.GDDuckButtonObjects2= [];
gdjs.GameCode.GDDuckButtonObjects3= [];
gdjs.GameCode.GDDuckButtonObjects4= [];
gdjs.GameCode.GDDuckButtonObjects5= [];
gdjs.GameCode.GDDuckButtonObjects6= [];
gdjs.GameCode.GDLimitObjects1= [];
gdjs.GameCode.GDLimitObjects2= [];
gdjs.GameCode.GDLimitObjects3= [];
gdjs.GameCode.GDLimitObjects4= [];
gdjs.GameCode.GDLimitObjects5= [];
gdjs.GameCode.GDLimitObjects6= [];
gdjs.GameCode.GDMonoObjects1= [];
gdjs.GameCode.GDMonoObjects2= [];
gdjs.GameCode.GDMonoObjects3= [];
gdjs.GameCode.GDMonoObjects4= [];
gdjs.GameCode.GDMonoObjects5= [];
gdjs.GameCode.GDMonoObjects6= [];
gdjs.GameCode.GDBanana2Objects1= [];
gdjs.GameCode.GDBanana2Objects2= [];
gdjs.GameCode.GDBanana2Objects3= [];
gdjs.GameCode.GDBanana2Objects4= [];
gdjs.GameCode.GDBanana2Objects5= [];
gdjs.GameCode.GDBanana2Objects6= [];
gdjs.GameCode.GDIslandObstacleObjects1= [];
gdjs.GameCode.GDIslandObstacleObjects2= [];
gdjs.GameCode.GDIslandObstacleObjects3= [];
gdjs.GameCode.GDIslandObstacleObjects4= [];
gdjs.GameCode.GDIslandObstacleObjects5= [];
gdjs.GameCode.GDIslandObstacleObjects6= [];
gdjs.GameCode.GDNewTextObjects1= [];
gdjs.GameCode.GDNewTextObjects2= [];
gdjs.GameCode.GDNewTextObjects3= [];
gdjs.GameCode.GDNewTextObjects4= [];
gdjs.GameCode.GDNewTextObjects5= [];
gdjs.GameCode.GDNewTextObjects6= [];

gdjs.GameCode.conditionTrue_0 = {val:false};
gdjs.GameCode.condition0IsTrue_0 = {val:false};
gdjs.GameCode.condition1IsTrue_0 = {val:false};
gdjs.GameCode.condition2IsTrue_0 = {val:false};
gdjs.GameCode.condition3IsTrue_0 = {val:false};
gdjs.GameCode.conditionTrue_1 = {val:false};
gdjs.GameCode.condition0IsTrue_1 = {val:false};
gdjs.GameCode.condition1IsTrue_1 = {val:false};
gdjs.GameCode.condition2IsTrue_1 = {val:false};
gdjs.GameCode.condition3IsTrue_1 = {val:false};


gdjs.GameCode.eventsList0 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.GameCode.GDScoreTextObjects2);
gdjs.copyArray(runtimeScene.getObjects("TutorialJuego"), gdjs.GameCode.GDTutorialJuegoObjects2);
{for(var i = 0, len = gdjs.GameCode.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDScoreTextObjects2[i].setString("Touch to start running.");
}
}{for(var i = 0, len = gdjs.GameCode.GDTutorialJuegoObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDTutorialJuegoObjects2[i].hide();
}
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = !(gdjs.evtTools.systemInfo.hasTouchScreen(runtimeScene));
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Limit"), gdjs.GameCode.GDLimitObjects1);
{for(var i = 0, len = gdjs.GameCode.GDLimitObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDLimitObjects1[i].hide();
}
}}

}


};gdjs.GameCode.eventsList1 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Limit"), gdjs.GameCode.GDLimitObjects3);
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects3);
gdjs.copyArray(runtimeScene.getObjects("TutorialJuego"), gdjs.GameCode.GDTutorialJuegoObjects3);
{for(var i = 0, len = gdjs.GameCode.GDLimitObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDLimitObjects3[i].hide();
}
for(var i = 0, len = gdjs.GameCode.GDTutorialJuegoObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDTutorialJuegoObjects3[i].hide();
}
}{for(var i = 0, len = gdjs.GameCode.GDMonoObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects3[i].setAnimationName("Run");
}
}{for(var i = 0, len = gdjs.GameCode.GDMonoObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects3[i].activateBehavior("PlatformerObject", true);
}
}{gdjs.evtTools.sound.playMusic(runtimeScene, "DesertMusic.mp3", true, 50, 1);
}}

}


{



}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition0IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9842548);
}
}if (gdjs.GameCode.condition0IsTrue_0.val) {
}

}


};gdjs.GameCode.eventsList2 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition0IsTrue_0;
gdjs.GameCode.condition0IsTrue_1.val = false;
gdjs.GameCode.condition1IsTrue_1.val = false;
{
gdjs.GameCode.condition0IsTrue_1.val = gdjs.evtTools.input.anyKeyPressed(runtimeScene);
if( gdjs.GameCode.condition0IsTrue_1.val ) {
    gdjs.GameCode.conditionTrue_1.val = true;
}
}
{
gdjs.GameCode.condition1IsTrue_1.val = gdjs.evtTools.input.hasAnyTouchStarted(runtimeScene);
if( gdjs.GameCode.condition1IsTrue_1.val ) {
    gdjs.GameCode.conditionTrue_1.val = true;
}
}
{
}
}
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(1).setString("Playing");
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "obstacle_spawn");
}
{ //Subevents
gdjs.GameCode.eventsList1(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList3 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "Preparing";
}if (gdjs.GameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList2(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList4 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDMonoObjects4, gdjs.GameCode.GDMonoObjects5);


gdjs.GameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDMonoObjects5[i].hasAnimationEnded() ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects5[k] = gdjs.GameCode.GDMonoObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects5.length = k;}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDMonoObjects5 */
{for(var i = 0, len = gdjs.GameCode.GDMonoObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects5[i].setAnimationName("Run");
}
}}

}


{



}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition0IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9758900);
}
}if (gdjs.GameCode.condition0IsTrue_0.val) {
}

}


};gdjs.GameCode.eventsList5 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects5);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDMonoObjects5[i].getBehavior("PlatformerObject").isJumping() ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects5[k] = gdjs.GameCode.GDMonoObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects5.length = k;}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9760500);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDMonoObjects5 */
{gdjs.evtTools.sound.playSound(runtimeScene, "Jump.mp3", false, 100, 1);
}{for(var i = 0, len = gdjs.GameCode.GDMonoObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects5[i].setAnimationName("Jump");
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects4);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDMonoObjects4[i].isCurrentAnimationName("Duck") ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects4[k] = gdjs.GameCode.GDMonoObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects4.length = k;}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9761348);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Skid.mp3", false, 30, 1);
}}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDJumpButtonObjects4Objects = Hashtable.newFrom({"JumpButton": gdjs.GameCode.GDJumpButtonObjects4});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDDuckButtonObjects3Objects = Hashtable.newFrom({"DuckButton": gdjs.GameCode.GDDuckButtonObjects3});
gdjs.GameCode.eventsList6 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("JumpButton"), gdjs.GameCode.GDJumpButtonObjects4);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDJumpButtonObjects4Objects, runtimeScene, true, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects4);
{for(var i = 0, len = gdjs.GameCode.GDMonoObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects4[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("DuckButton"), gdjs.GameCode.GDDuckButtonObjects3);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.cursorOnObject(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDDuckButtonObjects3Objects, runtimeScene, true, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects3);
{for(var i = 0, len = gdjs.GameCode.GDMonoObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects3[i].setAnimationName("Duck");
}
}}

}


};gdjs.GameCode.eventsList7 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Space");
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects4);
{for(var i = 0, len = gdjs.GameCode.GDMonoObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects4[i].getBehavior("PlatformerObject").simulateJumpKey();
}
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects4);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
gdjs.GameCode.condition2IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "Down");
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDMonoObjects4[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.GameCode.condition1IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects4[k] = gdjs.GameCode.GDMonoObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects4.length = k;}if ( gdjs.GameCode.condition1IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition2IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9763172);
}
}}
}
if (gdjs.GameCode.condition2IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDMonoObjects4 */
{for(var i = 0, len = gdjs.GameCode.GDMonoObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects4[i].setAnimationName("");
}
}}

}


{



}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9763884);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList6(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList8 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects4);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDMonoObjects4[i].getBehavior("PlatformerObject").isOnFloor() ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects4[k] = gdjs.GameCode.GDMonoObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects4.length = k;}if (gdjs.GameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList4(runtimeScene);} //End of subevents
}

}


{

gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects4);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects4.length;i<l;++i) {
    if ( !(gdjs.GameCode.GDMonoObjects4[i].getBehavior("PlatformerObject").isOnFloor()) ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects4[k] = gdjs.GameCode.GDMonoObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects4.length = k;}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
{gdjs.GameCode.conditionTrue_1 = gdjs.GameCode.condition1IsTrue_0;
gdjs.GameCode.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(9759636);
}
}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
}

}


{


gdjs.GameCode.eventsList5(runtimeScene);
}


{


gdjs.GameCode.eventsList7(runtimeScene);
}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMonoObjects4Objects = Hashtable.newFrom({"Mono": gdjs.GameCode.GDMonoObjects4});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBananaObjects4Objects = Hashtable.newFrom({"Banana": gdjs.GameCode.GDBananaObjects4});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBonusParticleObjects4Objects = Hashtable.newFrom({"BonusParticle": gdjs.GameCode.GDBonusParticleObjects4});
gdjs.GameCode.eventsList9 = function(runtimeScene) {

{


{
{runtimeScene.getGame().getVariables().getFromIndex(0).add(Math.round(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) * 100));
}}

}


{

gdjs.copyArray(runtimeScene.getObjects("Banana"), gdjs.GameCode.GDBananaObjects4);
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects4);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMonoObjects4Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBananaObjects4Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDBananaObjects4 */
/* Reuse gdjs.GameCode.GDMonoObjects4 */
gdjs.GameCode.GDBonusParticleObjects4.length = 0;

{runtimeScene.getGame().getVariables().getFromIndex(0).add(500);
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBonusParticleObjects4Objects, (( gdjs.GameCode.GDMonoObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDMonoObjects4[0].getCenterXInScene()), (( gdjs.GameCode.GDMonoObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDMonoObjects4[0].getCenterYInScene()), "");
}{for(var i = 0, len = gdjs.GameCode.GDBonusParticleObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDBonusParticleObjects4[i].setAngle(-(90));
}
}{for(var i = 0, len = gdjs.GameCode.GDBananaObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDBananaObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "Bonus.mp3", false, 100, 0.5);
}}

}


{


{
gdjs.copyArray(runtimeScene.getObjects("BonusParticle"), gdjs.GameCode.GDBonusParticleObjects3);
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects3);
{for(var i = 0, len = gdjs.GameCode.GDBonusParticleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBonusParticleObjects3[i].setCenterPositionInScene((( gdjs.GameCode.GDMonoObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDMonoObjects3[0].getCenterXInScene()),(( gdjs.GameCode.GDMonoObjects3.length === 0 ) ? 0 :gdjs.GameCode.GDMonoObjects3[0].getCenterYInScene()));
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects4Objects = Hashtable.newFrom({"CactusObstacle": gdjs.GameCode.GDCactusObstacleObjects4});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDIslandObstacleObjects4Objects = Hashtable.newFrom({"IslandObstacle": gdjs.GameCode.GDIslandObstacleObjects4});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBananaObjects5Objects = Hashtable.newFrom({"Banana": gdjs.GameCode.GDBananaObjects5});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBananaObjects4Objects = Hashtable.newFrom({"Banana": gdjs.GameCode.GDBananaObjects4});
gdjs.GameCode.eventsList10 = function(runtimeScene) {

{

gdjs.copyArray(gdjs.GameCode.GDIslandObstacleObjects4, gdjs.GameCode.GDIslandObstacleObjects5);


gdjs.GameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDIslandObstacleObjects5.length;i<l;++i) {
    if ( gdjs.GameCode.GDIslandObstacleObjects5[i].getVariableNumber(gdjs.GameCode.GDIslandObstacleObjects5[i].getVariables().get("Reward")) == 0 ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDIslandObstacleObjects5[k] = gdjs.GameCode.GDIslandObstacleObjects5[i];
        ++k;
    }
}
gdjs.GameCode.GDIslandObstacleObjects5.length = k;}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDIslandObstacleObjects5 */
gdjs.GameCode.GDBananaObjects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBananaObjects5Objects, (( gdjs.GameCode.GDIslandObstacleObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDIslandObstacleObjects5[0].getPointX("RewardUp")), (( gdjs.GameCode.GDIslandObstacleObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDIslandObstacleObjects5[0].getPointY("RewardUp")), "");
}{for(var i = 0, len = gdjs.GameCode.GDBananaObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDBananaObjects5[i].addPolarForce(180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), 1);
}
}}

}


{

/* Reuse gdjs.GameCode.GDIslandObstacleObjects4 */

gdjs.GameCode.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDIslandObstacleObjects4.length;i<l;++i) {
    if ( gdjs.GameCode.GDIslandObstacleObjects4[i].getVariableNumber(gdjs.GameCode.GDIslandObstacleObjects4[i].getVariables().get("Reward")) == 1 ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDIslandObstacleObjects4[k] = gdjs.GameCode.GDIslandObstacleObjects4[i];
        ++k;
    }
}
gdjs.GameCode.GDIslandObstacleObjects4.length = k;}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDIslandObstacleObjects4 */
gdjs.GameCode.GDBananaObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDBananaObjects4Objects, (( gdjs.GameCode.GDIslandObstacleObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDIslandObstacleObjects4[0].getPointX("RewardDown")), (( gdjs.GameCode.GDIslandObstacleObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDIslandObstacleObjects4[0].getPointY("RewardDown")), "");
}{for(var i = 0, len = gdjs.GameCode.GDBananaObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDBananaObjects4[i].addPolarForce(180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), 1);
}
}}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects5Objects = Hashtable.newFrom({"CactusObstacle": gdjs.GameCode.GDCactusObstacleObjects5});
gdjs.GameCode.eventsList11 = function(runtimeScene) {

};gdjs.GameCode.eventsList12 = function(runtimeScene) {

{


gdjs.GameCode.stopDoWhile5 = false;
do {gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.GameCode.GDPlatformObjects5);
gdjs.GameCode.GDCactusObstacleObjects5.length = 0;

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) < gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(5));
}if (gdjs.GameCode.condition0IsTrue_0.val) {
if (true) {
{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects5Objects, 100 + gdjs.evtTools.window.getGameResolutionWidth(runtimeScene) + gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) * 70, (( gdjs.GameCode.GDPlatformObjects5.length === 0 ) ? 0 :gdjs.GameCode.GDPlatformObjects5[0].getAABBTop()), "");
}{for(var i = 0, len = gdjs.GameCode.GDCactusObstacleObjects5.length ;i < len;++i) {
    gdjs.GameCode.GDCactusObstacleObjects5[i].addPolarForce(180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), 1);
}
}{runtimeScene.getVariables().getFromIndex(6).add(1);
}
{ //Subevents: 
gdjs.GameCode.eventsList11(runtimeScene);} //Subevents end.
}
} else gdjs.GameCode.stopDoWhile5 = true; 
} while ( !gdjs.GameCode.stopDoWhile5 );

}


{


{
{runtimeScene.getVariables().getFromIndex(6).setNumber(0);
}}

}


};gdjs.GameCode.eventsList13 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 0;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.GameCode.GDPlatformObjects4);
gdjs.GameCode.GDCactusObstacleObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects4Objects, gdjs.randomInRange(75, 125) + gdjs.evtTools.window.getGameResolutionWidth(runtimeScene), (( gdjs.GameCode.GDPlatformObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPlatformObjects4[0].getAABBTop()), "");
}{for(var i = 0, len = gdjs.GameCode.GDCactusObstacleObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDCactusObstacleObjects4[i].addPolarForce(180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), 1);
}
}}

}


{



}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 1;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.GameCode.GDPlatformObjects4);
gdjs.GameCode.GDIslandObstacleObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDIslandObstacleObjects4Objects, gdjs.randomInRange(75, 125) + gdjs.evtTools.window.getGameResolutionWidth(runtimeScene), (( gdjs.GameCode.GDPlatformObjects4.length === 0 ) ? 0 :gdjs.GameCode.GDPlatformObjects4[0].getAABBTop()) - 64, "");
}{for(var i = 0, len = gdjs.GameCode.GDIslandObstacleObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDIslandObstacleObjects4[i].returnVariable(gdjs.GameCode.GDIslandObstacleObjects4[i].getVariables().get("Reward")).setNumber(gdjs.randomInRange(0, 2));
}
}{for(var i = 0, len = gdjs.GameCode.GDIslandObstacleObjects4.length ;i < len;++i) {
    gdjs.GameCode.GDIslandObstacleObjects4[i].addPolarForce(180, gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)), 1);
}
}
{ //Subevents
gdjs.GameCode.eventsList10(runtimeScene);} //End of subevents
}

}


{



}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) == 2;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(5).setNumber(gdjs.randomInRange(1, 1 + Math.round(gdjs.evtTools.common.clamp(gdjs.evtTools.variable.getVariableNumber(runtimeScene.getGame().getVariables().getFromIndex(0)) / 3000, 0, 4))));
}
{ //Subevents
gdjs.GameCode.eventsList12(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList14 = function(runtimeScene) {

{



}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) < 2000;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).add(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) * 8);
}}

}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4)) > 0.7;
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(4).sub(gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene) / 30);
}}

}


{



}


{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.getTimerElapsedTimeInSecondsOrNaN(runtimeScene, "obstacle_spawn") >= gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(4));
}if (gdjs.GameCode.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(0).setNumber(gdjs.randomInRange(0, 2));
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "obstacle_spawn");
}
{ //Subevents
gdjs.GameCode.eventsList13(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMonoObjects2Objects = Hashtable.newFrom({"Mono": gdjs.GameCode.GDMonoObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects2Objects = Hashtable.newFrom({"CactusObstacle": gdjs.GameCode.GDCactusObstacleObjects2});
gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects3ObjectsGDgdjs_46GameCode_46GDIslandObstacleObjects3ObjectsGDgdjs_46GameCode_46GDBananaObjects3Objects = Hashtable.newFrom({"CactusObstacle": gdjs.GameCode.GDCactusObstacleObjects3, "IslandObstacle": gdjs.GameCode.GDIslandObstacleObjects3, "Banana": gdjs.GameCode.GDBananaObjects3});
gdjs.GameCode.eventsList15 = function(runtimeScene) {

{


{
gdjs.copyArray(runtimeScene.getObjects("Banana"), gdjs.GameCode.GDBananaObjects3);
gdjs.copyArray(gdjs.GameCode.GDCactusObstacleObjects2, gdjs.GameCode.GDCactusObstacleObjects3);

gdjs.copyArray(runtimeScene.getObjects("IslandObstacle"), gdjs.GameCode.GDIslandObstacleObjects3);
{gdjs.evtTools.object.pickAllObjects((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects3ObjectsGDgdjs_46GameCode_46GDIslandObstacleObjects3ObjectsGDgdjs_46GameCode_46GDBananaObjects3Objects);
}{for(var i = 0, len = gdjs.GameCode.GDCactusObstacleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDCactusObstacleObjects3[i].clearForces();
}
for(var i = 0, len = gdjs.GameCode.GDIslandObstacleObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDIslandObstacleObjects3[i].clearForces();
}
for(var i = 0, len = gdjs.GameCode.GDBananaObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBananaObjects3[i].clearForces();
}
}}

}


{


{
{gdjs.evtTools.sound.playSound(runtimeScene, "Death.mp3", false, 30, 0.5);
}}

}


};gdjs.GameCode.eventsList16 = function(runtimeScene) {

{



}


{

gdjs.copyArray(runtimeScene.getObjects("CactusObstacle"), gdjs.GameCode.GDCactusObstacleObjects2);
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects2);

gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDMonoObjects2Objects, gdjs.GameCode.mapOfGDgdjs_46GameCode_46GDCactusObstacleObjects2Objects, false, runtimeScene, false);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
/* Reuse gdjs.GameCode.GDMonoObjects2 */
{for(var i = 0, len = gdjs.GameCode.GDMonoObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects2[i].setAnimationName("Dead");
}
}{runtimeScene.getVariables().getFromIndex(1).setString("Dead");
}{gdjs.evtTools.runtimeScene.pauseTimer(runtimeScene, "obstacle_spawn");
}
{ //Subevents
gdjs.GameCode.eventsList15(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList17 = function(runtimeScene) {

{



}


{


{
gdjs.copyArray(runtimeScene.getObjects("Background"), gdjs.GameCode.GDBackgroundObjects3);
gdjs.copyArray(runtimeScene.getObjects("Platform"), gdjs.GameCode.GDPlatformObjects3);
{for(var i = 0, len = gdjs.GameCode.GDPlatformObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDPlatformObjects3[i].setXOffset(gdjs.GameCode.GDPlatformObjects3[i].getXOffset() + (gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}{for(var i = 0, len = gdjs.GameCode.GDBackgroundObjects3.length ;i < len;++i) {
    gdjs.GameCode.GDBackgroundObjects3[i].setXOffset(gdjs.GameCode.GDBackgroundObjects3[i].getXOffset() + ((gdjs.evtTools.variable.getVariableNumber(runtimeScene.getVariables().getFromIndex(3)) / 500) * 60 * gdjs.evtTools.runtimeScene.getElapsedTimeInSeconds(runtimeScene)));
}
}}

}


{


{
}

}


{


gdjs.GameCode.eventsList8(runtimeScene);
}


{


gdjs.GameCode.eventsList9(runtimeScene);
}


{


gdjs.GameCode.eventsList14(runtimeScene);
}


{


gdjs.GameCode.eventsList16(runtimeScene);
}


};gdjs.GameCode.eventsList18 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "Playing";
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("ScoreText"), gdjs.GameCode.GDScoreTextObjects2);
{for(var i = 0, len = gdjs.GameCode.GDScoreTextObjects2.length ;i < len;++i) {
    gdjs.GameCode.GDScoreTextObjects2[i].setString("Score   " + gdjs.evtTools.variable.getVariableString(runtimeScene.getGame().getVariables().getFromIndex(0)));
}
}
{ //Subevents
gdjs.GameCode.eventsList17(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList19 = function(runtimeScene) {

{

gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects1);

gdjs.GameCode.condition0IsTrue_0.val = false;
gdjs.GameCode.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDMonoObjects1[i].isCurrentAnimationName("Dead") ) {
        gdjs.GameCode.condition0IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects1[k] = gdjs.GameCode.GDMonoObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects1.length = k;}if ( gdjs.GameCode.condition0IsTrue_0.val ) {
{
for(var i = 0, k = 0, l = gdjs.GameCode.GDMonoObjects1.length;i<l;++i) {
    if ( gdjs.GameCode.GDMonoObjects1[i].hasAnimationEnded() ) {
        gdjs.GameCode.condition1IsTrue_0.val = true;
        gdjs.GameCode.GDMonoObjects1[k] = gdjs.GameCode.GDMonoObjects1[i];
        ++k;
    }
}
gdjs.GameCode.GDMonoObjects1.length = k;}}
if (gdjs.GameCode.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "GameOver", true);
}}

}


};gdjs.GameCode.eventsList20 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.variable.getVariableString(runtimeScene.getVariables().getFromIndex(1)) == "Dead";
}if (gdjs.GameCode.condition0IsTrue_0.val) {

{ //Subevents
gdjs.GameCode.eventsList19(runtimeScene);} //End of subevents
}

}


};gdjs.GameCode.eventsList21 = function(runtimeScene) {

{


gdjs.GameCode.eventsList3(runtimeScene);
}


{


gdjs.GameCode.eventsList18(runtimeScene);
}


{


gdjs.GameCode.eventsList20(runtimeScene);
}


};gdjs.GameCode.eventsList22 = function(runtimeScene) {

{


gdjs.GameCode.condition0IsTrue_0.val = false;
{
gdjs.GameCode.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs.GameCode.condition0IsTrue_0.val) {
gdjs.copyArray(runtimeScene.getObjects("Mono"), gdjs.GameCode.GDMonoObjects1);
{for(var i = 0, len = gdjs.GameCode.GDMonoObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects1[i].setAnimationName("Idle");
}
}{runtimeScene.getGame().getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs.GameCode.GDMonoObjects1.length ;i < len;++i) {
    gdjs.GameCode.GDMonoObjects1[i].activateBehavior("PlatformerObject", true);
}
}
{ //Subevents
gdjs.GameCode.eventsList0(runtimeScene);} //End of subevents
}

}


{


gdjs.GameCode.eventsList21(runtimeScene);
}


};

gdjs.GameCode.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs.GameCode.GDPlatformObjects1.length = 0;
gdjs.GameCode.GDPlatformObjects2.length = 0;
gdjs.GameCode.GDPlatformObjects3.length = 0;
gdjs.GameCode.GDPlatformObjects4.length = 0;
gdjs.GameCode.GDPlatformObjects5.length = 0;
gdjs.GameCode.GDPlatformObjects6.length = 0;
gdjs.GameCode.GDBackgroundObjects1.length = 0;
gdjs.GameCode.GDBackgroundObjects2.length = 0;
gdjs.GameCode.GDBackgroundObjects3.length = 0;
gdjs.GameCode.GDBackgroundObjects4.length = 0;
gdjs.GameCode.GDBackgroundObjects5.length = 0;
gdjs.GameCode.GDBackgroundObjects6.length = 0;
gdjs.GameCode.GDCactusObstacleObjects1.length = 0;
gdjs.GameCode.GDCactusObstacleObjects2.length = 0;
gdjs.GameCode.GDCactusObstacleObjects3.length = 0;
gdjs.GameCode.GDCactusObstacleObjects4.length = 0;
gdjs.GameCode.GDCactusObstacleObjects5.length = 0;
gdjs.GameCode.GDCactusObstacleObjects6.length = 0;
gdjs.GameCode.GDScoreTextObjects1.length = 0;
gdjs.GameCode.GDScoreTextObjects2.length = 0;
gdjs.GameCode.GDScoreTextObjects3.length = 0;
gdjs.GameCode.GDScoreTextObjects4.length = 0;
gdjs.GameCode.GDScoreTextObjects5.length = 0;
gdjs.GameCode.GDScoreTextObjects6.length = 0;
gdjs.GameCode.GDTutorialJuegoObjects1.length = 0;
gdjs.GameCode.GDTutorialJuegoObjects2.length = 0;
gdjs.GameCode.GDTutorialJuegoObjects3.length = 0;
gdjs.GameCode.GDTutorialJuegoObjects4.length = 0;
gdjs.GameCode.GDTutorialJuegoObjects5.length = 0;
gdjs.GameCode.GDTutorialJuegoObjects6.length = 0;
gdjs.GameCode.GDBananaObjects1.length = 0;
gdjs.GameCode.GDBananaObjects2.length = 0;
gdjs.GameCode.GDBananaObjects3.length = 0;
gdjs.GameCode.GDBananaObjects4.length = 0;
gdjs.GameCode.GDBananaObjects5.length = 0;
gdjs.GameCode.GDBananaObjects6.length = 0;
gdjs.GameCode.GDBonusParticleObjects1.length = 0;
gdjs.GameCode.GDBonusParticleObjects2.length = 0;
gdjs.GameCode.GDBonusParticleObjects3.length = 0;
gdjs.GameCode.GDBonusParticleObjects4.length = 0;
gdjs.GameCode.GDBonusParticleObjects5.length = 0;
gdjs.GameCode.GDBonusParticleObjects6.length = 0;
gdjs.GameCode.GDJumpButtonObjects1.length = 0;
gdjs.GameCode.GDJumpButtonObjects2.length = 0;
gdjs.GameCode.GDJumpButtonObjects3.length = 0;
gdjs.GameCode.GDJumpButtonObjects4.length = 0;
gdjs.GameCode.GDJumpButtonObjects5.length = 0;
gdjs.GameCode.GDJumpButtonObjects6.length = 0;
gdjs.GameCode.GDDuckButtonObjects1.length = 0;
gdjs.GameCode.GDDuckButtonObjects2.length = 0;
gdjs.GameCode.GDDuckButtonObjects3.length = 0;
gdjs.GameCode.GDDuckButtonObjects4.length = 0;
gdjs.GameCode.GDDuckButtonObjects5.length = 0;
gdjs.GameCode.GDDuckButtonObjects6.length = 0;
gdjs.GameCode.GDLimitObjects1.length = 0;
gdjs.GameCode.GDLimitObjects2.length = 0;
gdjs.GameCode.GDLimitObjects3.length = 0;
gdjs.GameCode.GDLimitObjects4.length = 0;
gdjs.GameCode.GDLimitObjects5.length = 0;
gdjs.GameCode.GDLimitObjects6.length = 0;
gdjs.GameCode.GDMonoObjects1.length = 0;
gdjs.GameCode.GDMonoObjects2.length = 0;
gdjs.GameCode.GDMonoObjects3.length = 0;
gdjs.GameCode.GDMonoObjects4.length = 0;
gdjs.GameCode.GDMonoObjects5.length = 0;
gdjs.GameCode.GDMonoObjects6.length = 0;
gdjs.GameCode.GDBanana2Objects1.length = 0;
gdjs.GameCode.GDBanana2Objects2.length = 0;
gdjs.GameCode.GDBanana2Objects3.length = 0;
gdjs.GameCode.GDBanana2Objects4.length = 0;
gdjs.GameCode.GDBanana2Objects5.length = 0;
gdjs.GameCode.GDBanana2Objects6.length = 0;
gdjs.GameCode.GDIslandObstacleObjects1.length = 0;
gdjs.GameCode.GDIslandObstacleObjects2.length = 0;
gdjs.GameCode.GDIslandObstacleObjects3.length = 0;
gdjs.GameCode.GDIslandObstacleObjects4.length = 0;
gdjs.GameCode.GDIslandObstacleObjects5.length = 0;
gdjs.GameCode.GDIslandObstacleObjects6.length = 0;
gdjs.GameCode.GDNewTextObjects1.length = 0;
gdjs.GameCode.GDNewTextObjects2.length = 0;
gdjs.GameCode.GDNewTextObjects3.length = 0;
gdjs.GameCode.GDNewTextObjects4.length = 0;
gdjs.GameCode.GDNewTextObjects5.length = 0;
gdjs.GameCode.GDNewTextObjects6.length = 0;

gdjs.GameCode.eventsList22(runtimeScene);
return;

}

gdjs['GameCode'] = gdjs.GameCode;
